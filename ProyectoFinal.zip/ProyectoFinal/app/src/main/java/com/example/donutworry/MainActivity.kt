package com.example.donutworry

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        val btnRealizarPedido: Button = findViewById(R.id.btnRealizarPedido)
        val btnVerHistorial: Button = findViewById(R.id.btnVerHistorial)

        btnRealizarPedido.setOnClickListener {
            startActivity(Intent(this, PedidosActivity::class.java))
        }

        btnVerHistorial.setOnClickListener {
            startActivity(Intent(this, HistorialActivity::class.java))
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_pedidos -> startActivity(Intent(this, PedidosActivity::class.java))
            R.id.nav_historial -> startActivity(Intent(this, HistorialActivity::class.java))
            R.id.nav_ayuda -> startActivity(Intent(this, AyudaActivity::class.java))
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_toolbar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val db = admin.writableDatabase

        when (item.itemId) {
            R.id.action_perfil -> {
                startActivity(Intent(this, PerfilActivity::class.java))
                return true
            }
            R.id.action_configuracion -> {
                startActivity(Intent(this, ConfiguracionActivity::class.java))
                return true
            }

            R.id.action_reenviar_ultimo -> {
                try {
                    val cursor = db.rawQuery("SELECT descripcion, cliente, total FROM pedidos ORDER BY codigo DESC LIMIT 1", null)

                    if (cursor.moveToFirst()) {
                        val descAnterior = cursor.getString(0)
                        val cliente = cursor.getString(1)
                        val total = cursor.getDouble(2)

                        val fechaNueva = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
                        val descBase = descAnterior.substringBefore("(")
                        val nuevaDescripcion = "$descBase($fechaNueva) - REENVÍO"

                        val registro = ContentValues()
                        registro.put("descripcion", nuevaDescripcion)
                        registro.put("cliente", cliente)
                        registro.put("total", total)

                        db.insert("pedidos", null, registro)
                        Toast.makeText(this, "¡Pedido reenviado exitosamente! 🍩", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No hay pedidos para reenviar", Toast.LENGTH_SHORT).show()
                    }
                    cursor.close()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error al reenviar", Toast.LENGTH_SHORT).show()
                }
                return true
            }

            R.id.action_modificar_ultimo -> {
                val input = EditText(this)
                input.hint = "Nuevo nombre del cliente"

                val builder = AlertDialog.Builder(this)
                builder.setTitle("Modificar Pedido")
                builder.setMessage("Corrige el nombre del cliente en el último pedido:")
                builder.setView(input)

                builder.setPositiveButton("Actualizar") { _, _ ->
                    val nuevoNombre = input.text.toString()
                    if (nuevoNombre.isNotEmpty()) {
                        try {
                            db.execSQL("UPDATE pedidos SET cliente = '$nuevoNombre' WHERE codigo = (SELECT MAX(codigo) FROM pedidos)")
                            Toast.makeText(this, "Cliente actualizado a: $nuevoNombre ✅", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(this, "Error al modificar", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
                    }
                }
                builder.setNegativeButton("Cancelar", null)
                builder.show()
                return true
            }

            R.id.action_cancelar_ultimo -> {
                try {
                    db.execSQL("DELETE FROM pedidos WHERE codigo = (SELECT MAX(codigo) FROM pedidos)")
                    Toast.makeText(this, "Último pedido eliminado 🗑️", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "No hay pedidos para cancelar", Toast.LENGTH_SHORT).show()
                }
                return true
            }

            R.id.action_salir -> {
                val builder = AlertDialog.Builder(this)
                builder.setTitle("¿Cerrar Sesión?")
                builder.setMessage("¿Estás seguro de que quieres salir?")
                builder.setPositiveButton("Sí") { _, _ -> finish() }
                builder.setNegativeButton("No", null)
                builder.show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}