package com.example.donutworry

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        val btnRealizarPedido: Button = findViewById(R.id.btnRealizarPedido)
        val btnVerHistorial: Button = findViewById(R.id.btnVerHistorial)

        btnRealizarPedido.setOnClickListener {
            startActivity(Intent(this, PedidosActivity::class.java))
        }

        btnVerHistorial.setOnClickListener {
            startActivity(Intent(this, HistorialActivity::class.java))
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_inicio -> {
            }
            R.id.nav_pedidos -> {
                startActivity(Intent(this, PedidosActivity::class.java))
            }
            R.id.nav_historial -> {
                startActivity(Intent(this, HistorialActivity::class.java))
            }
            R.id.nav_ayuda -> {
                startActivity(Intent(this, AyudaActivity::class.java))
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_toolbar, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_perfil -> {
                startActivity(Intent(this, PerfilActivity::class.java))
                return true
            }
            R.id.action_configuracion -> {
                startActivity(Intent(this, ConfiguracionActivity::class.java))
                return true
            }
            R.id.action_salir -> {
                val builder = AlertDialog.Builder(this)
                builder.setTitle("¿Cerrar Sesión?")
                builder.setMessage("¿Estás seguro de que quieres salir?")
                builder.setPositiveButton("Sí") { _, _ -> finish() }
                builder.setNegativeButton("No", null)
                builder.show()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}