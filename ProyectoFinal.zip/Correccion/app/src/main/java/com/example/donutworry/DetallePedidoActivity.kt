package com.example.donutworry

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetallePedidoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_pedido)

        val tvResumenPedido: TextView = findViewById(R.id.tvResumenPedido)
        val tvDatosCliente: TextView = findViewById(R.id.tvDatosCliente)
        val btnRegresar: Button = findViewById(R.id.btnRegresar)

        val sabor = intent.getStringExtra("sabor") ?: "No especificado"
        val extras = intent.getStringExtra("extras") ?: "Ninguno"
        val nombre = intent.getStringExtra("nombre") ?: "No especificado"
        val direccion = intent.getStringExtra("direccion") ?: "No especificado"
        val total = intent.getDoubleExtra("total", 0.0)

        val resumenTexto = """
            Resumen del Pedido:
            Sabor: $sabor
            Extras: $extras
            Total: $${"%.2f".format(total)}
        """.trimIndent()

        val clienteTexto = """
            Datos del Cliente:
            Nombre: $nombre
            Dirección: $direccion
        """.trimIndent()

        tvResumenPedido.text = resumenTexto
        tvDatosCliente.text = clienteTexto

        btnRegresar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)

            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
        }
    }
}