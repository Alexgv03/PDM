package com.example.donutworry

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class ConfiguracionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuracion)

        val etNombreConfig: TextInputEditText = findViewById(R.id.etNombreConfig)
        val etDireccionConfig: TextInputEditText = findViewById(R.id.etDireccionConfig)
        val btnGuardar: Button = findViewById(R.id.btnGuardarConfig)
        val btnRegresar: Button = findViewById(R.id.btnRegresarConfig)

        val prefs = getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE)
        etNombreConfig.setText(prefs.getString("nombre_default", ""))
        etDireccionConfig.setText(prefs.getString("direccion_default", ""))

        btnGuardar.setOnClickListener {
            val nuevoNombre = etNombreConfig.text.toString()
            val nuevaDireccion = etDireccionConfig.text.toString()

            val editor = prefs.edit()
            editor.putString("nombre_default", nuevoNombre)
            editor.putString("direccion_default", nuevaDireccion)
            editor.apply()

            Toast.makeText(this, "Datos guardados ✅", Toast.LENGTH_SHORT).show()
        }

        btnRegresar.setOnClickListener { finish() }
    }
}