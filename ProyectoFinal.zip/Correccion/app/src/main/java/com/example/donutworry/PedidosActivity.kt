package com.example.donutworry

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PedidosActivity : AppCompatActivity() {

    private var total = 0.0
    private val precioBase = 35.0
    private val precioExtra = 5.0
    private lateinit var tvTotal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pedidos)

        val rgSabores: RadioGroup = findViewById(R.id.rgSabores)
        val cbChispas: CheckBox = findViewById(R.id.cbChispas)
        val cbAzucar: CheckBox = findViewById(R.id.cbAzucar)
        val cbRelleno: CheckBox = findViewById(R.id.cbRelleno)
        val etNombre: EditText = findViewById(R.id.etNombre)
        val etDireccion: EditText = findViewById(R.id.etDireccion)
        val btnRealizarPedido: Button = findViewById(R.id.btnRealizarPedido)
        val btnRegresarPedidos: Button = findViewById(R.id.btnRegresarPedidos)
        tvTotal = findViewById(R.id.tvTotal)

        val prefs = getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE)
        val nombreDefault = prefs.getString("nombre_default", "")
        val direccionDefault = prefs.getString("direccion_default", "")

        if (!nombreDefault.isNullOrEmpty()) etNombre.setText(nombreDefault)
        if (!direccionDefault.isNullOrEmpty()) etDireccion.setText(direccionDefault)

        val listener = { actualizarTotal() }
        rgSabores.setOnCheckedChangeListener { _, _ -> listener() }
        cbChispas.setOnCheckedChangeListener { _, _ -> listener() }
        cbAzucar.setOnCheckedChangeListener { _, _ -> listener() }
        cbRelleno.setOnCheckedChangeListener { _, _ -> listener() }

        btnRegresarPedidos.setOnClickListener { finish() }

        btnRealizarPedido.setOnClickListener {
            if (rgSabores.checkedRadioButtonId == -1) {
                Toast.makeText(this, "¡Elige un sabor! 🍩", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (etNombre.text.toString().trim().isEmpty()) {
                etNombre.error = "Falta nombre"
                return@setOnClickListener
            }
            if (etDireccion.text.toString().trim().isEmpty()) {
                etDireccion.error = "Falta dirección"
                return@setOnClickListener
            }

            val saborSeleccionado = when (rgSabores.checkedRadioButtonId) {
                R.id.rbChocolate -> "Chocolate"
                R.id.rbVainilla -> "Vainilla"
                R.id.rbFresa -> "Fresa"
                else -> "Ninguno"
            }

            val extrasSeleccionados = mutableListOf<String>()
            if (cbChispas.isChecked) extrasSeleccionados.add("Chispas")
            if (cbAzucar.isChecked) extrasSeleccionados.add("Azúcar Glass")
            if (cbRelleno.isChecked) extrasSeleccionados.add("Relleno")
            val extrasString = extrasSeleccionados.joinToString(", ")

            val nombre = etNombre.text.toString()
            val direccion = etDireccion.text.toString()

            val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
            val bd = admin.writableDatabase
            val registro = ContentValues()
            val fechaHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            val descripcion = "$saborSeleccionado con $extrasString ($fechaHora)"

            registro.put("descripcion", descripcion)
            registro.put("cliente", nombre)
            registro.put("total", total)

            bd.insert("pedidos", null, registro)
            bd.close()
            Toast.makeText(this, "Pedido guardado", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, DetallePedidoActivity::class.java)
            intent.putExtra("sabor", saborSeleccionado)
            intent.putExtra("extras", extrasString)
            intent.putExtra("nombre", nombre)
            intent.putExtra("direccion", direccion)
            intent.putExtra("total", total)
            startActivity(intent)
        }
        actualizarTotal()
    }

    private fun actualizarTotal() {
        total = precioBase
        if (findViewById<CheckBox>(R.id.cbChispas).isChecked) total += precioExtra
        if (findViewById<CheckBox>(R.id.cbAzucar).isChecked) total += precioExtra
        if (findViewById<CheckBox>(R.id.cbRelleno).isChecked) total += precioExtra
        tvTotal.text = "Total: $${"%.2f".format(total)}"
    }
}