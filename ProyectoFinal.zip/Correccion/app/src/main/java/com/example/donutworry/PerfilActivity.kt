package com.example.donutworry

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PerfilActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        val tvTotalPedidos: TextView = findViewById(R.id.tvTotalPedidos)
        val tvTotalGastado: TextView = findViewById(R.id.tvTotalGastado)
        val btnRegresar: Button = findViewById(R.id.btnRegresarPerfil)

        calcularEstadisticas(tvTotalPedidos, tvTotalGastado)

        btnRegresar.setOnClickListener {
            finish()
        }
    }

    private fun calcularEstadisticas(tvPedidos: TextView, tvGastado: TextView) {
        try {
            val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
            val bd = admin.readableDatabase

            val registro = bd.rawQuery("SELECT COUNT(*), COALESCE(SUM(total), 0) FROM pedidos", null)

            if (registro.moveToFirst()) {
                val cantidadPedidos = registro.getInt(0)
                val totalDinero = registro.getDouble(1)

                tvPedidos.text = cantidadPedidos.toString()
                tvGastado.text = "$${"%.2f".format(totalDinero)}"
            } else {
                tvPedidos.text = "0"
                tvGastado.text = "$0.00"
            }
            registro.close()
            bd.close()
        } catch (e: Exception) {
            tvPedidos.text = "0"
            tvGastado.text = "$0.00"
            e.printStackTrace()
        }
    }
}