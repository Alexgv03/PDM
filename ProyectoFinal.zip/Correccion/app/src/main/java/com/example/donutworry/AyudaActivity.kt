package com.example.donutworry

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AyudaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ayuda)

        val btnContactar: Button = findViewById(R.id.btnContactarSoporte)
        val btnRegresar: Button = findViewById(R.id.btnRegresarAyuda)

        btnContactar.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:soporte@donutworry.com")
                putExtra(Intent.EXTRA_SUBJECT, "Ayuda con mi pedido de DonutWorry")
                putExtra(Intent.EXTRA_TEXT, "Hola, necesito ayuda con...")
            }

            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "No se encontró app de correo", Toast.LENGTH_SHORT).show()
            }
        }

        btnRegresar.setOnClickListener {
            finish()
        }
    }
}