package com.example.donutworry

import android.database.Cursor
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog // Importar para confirmación opcional
import androidx.appcompat.app.AppCompatActivity

class HistorialActivity : AppCompatActivity() {

    private lateinit var lvHistorial: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        lvHistorial = findViewById(R.id.lvHistorial)
        val btnRegresar: Button = findViewById(R.id.btnRegresarHistorial)
        val btnBorrar: Button = findViewById(R.id.btnBorrarHistorial)

        cargarHistorial()

        btnRegresar.setOnClickListener { finish() }

        btnBorrar.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Borrar Todo")
            builder.setMessage("¿Estás seguro de que deseas eliminar todo el historial?")
            builder.setPositiveButton("Sí, borrar") { _, _ ->
                eliminarTodo()
            }
            builder.setNegativeButton("Cancelar", null)
            builder.show()
        }
    }

    private fun cargarHistorial() {
        val listaPedidos = ArrayList<String>()
        try {
            val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
            val bd = admin.readableDatabase
            val fila: Cursor = bd.rawQuery("select descripcion, cliente, total from pedidos", null)

            if (fila.moveToFirst()) {
                do {
                    val desc = fila.getString(0)
                    val cliente = fila.getString(1)
                    val total = fila.getDouble(2)
                    listaPedidos.add("$desc\nCliente: $cliente - Total: $${"%.2f".format(total)}")
                } while (fila.moveToNext())
            } else {
                listaPedidos.add("No hay pedidos registrados.")
            }
            bd.close()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar", Toast.LENGTH_SHORT).show()
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaPedidos)
        lvHistorial.adapter = adapter
    }

    private fun eliminarTodo() {
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val bd = admin.writableDatabase
        bd.execSQL("DELETE FROM pedidos")
        bd.close()
        Toast.makeText(this, "Historial eliminado", Toast.LENGTH_SHORT).show()
        cargarHistorial()
    }
}