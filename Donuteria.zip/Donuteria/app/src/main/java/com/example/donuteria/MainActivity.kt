package com.example.donuteria

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.donuteria.ui.theme.DonuteriaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DonuteriaTheme {
                DonuteriaMenu()
            }
        }
    }
}

@Composable
fun DonuteriaMenu() {
    val context = LocalContext.current

    var nombre by remember { mutableStateOf("") }
    var tipoDona by remember { mutableStateOf("Chocolate") }

    // Estado de los toppings
    var conChispas by remember { mutableStateOf(false) }
    var conRelleno by remember { mutableStateOf(false) }
    var conAzucar by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "🍩 Bienvenida a Donut Worry 🍩",
            style = MaterialTheme.typography.headlineSmall
        )

        Text("Tu nombre:")
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Escribe tu nombre") }
        )

        Text("Selecciona el tipo de dona:")

        Row {
            RadioButton(selected = tipoDona == "Chocolate", onClick = { tipoDona = "Chocolate" })
            Text("Chocolate")
            Spacer(modifier = Modifier.width(16.dp))
            RadioButton(selected = tipoDona == "Fresa", onClick = { tipoDona = "Fresa" })
            Text("Fresa")
            Spacer(modifier = Modifier.width(16.dp))
            RadioButton(selected = tipoDona == "Vainilla", onClick = { tipoDona = "Vainilla" })
            Text("Vainilla")
        }

        Text("Selecciona toppings:")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = conChispas, onCheckedChange = { conChispas = it })
            Text("Chispas de chocolate")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = conRelleno, onCheckedChange = { conRelleno = it })
            Text("Relleno de crema")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = conAzucar, onCheckedChange = { conAzucar = it })
            Text("Azúcar glass")
        }

        Button(onClick = {
            val intent = Intent(context, PedidosActivity::class.java)
            intent.putExtra("NOMBRE_CLIENTE", nombre)
            intent.putExtra("TIPO_DONA", tipoDona)
            intent.putExtra("CHISPAS", conChispas)
            intent.putExtra("RELLENO", conRelleno)
            intent.putExtra("AZUCAR", conAzucar)
            context.startActivity(intent)
        }) {
            Text("Hacer pedido 🍩")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DonuteriaMenuPreview() {
    DonuteriaTheme {
        DonuteriaMenu()
    }
}


