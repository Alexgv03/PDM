package com.example.donuteria

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.donuteria.ui.theme.DonuteriaTheme

class PedidosActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val nombre = intent.getStringExtra("NOMBRE_CLIENTE") ?: "Cliente"
        val tipoDona = intent.getStringExtra("TIPO_DONA") ?: "Chocolate"
        val chispas = intent.getBooleanExtra("CHISPAS", false)
        val relleno = intent.getBooleanExtra("RELLENO", false)
        val azucar = intent.getBooleanExtra("AZUCAR", false)

        setContent {
            DonuteriaTheme {
                PantallaPedidos(nombre, tipoDona, chispas, relleno, azucar)
            }
        }
    }
}

@Composable
fun PantallaPedidos(
    nombre: String,
    tipoDona: String,
    chispas: Boolean,
    relleno: Boolean,
    azucar: Boolean
) {
    // Selección de imagen según tipo de dona
    val imagenDona = when (tipoDona) {
        "Chocolate" -> R.drawable.chocolate
        "Fresa" -> R.drawable.fresa
        "Vainilla" -> R.drawable.vainilla
        else -> R.drawable.donita // imagen por defecto
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🍩 Pedido recibido 🍩", style = MaterialTheme.typography.headlineSmall)
        Text("Hola $nombre 💛")
        Text("Tu pedido: $tipoDona")

        // Imagen de la dona
        Image(
            painter = painterResource(id = imagenDona),
            contentDescription = "Imagen de $tipoDona",
            modifier = Modifier.size(200.dp)
        )

        Text("Toppings seleccionados:")
        if (chispas) Text("- Chispas de chocolate")
        if (relleno) Text("- Relleno de crema")
        if (azucar) Text("- Azúcar glass")
        if (!chispas && !relleno && !azucar) Text("No seleccionaste toppings")

        Button(onClick = { /* acción futura */ }) {
            Text("Finalizar pedido 💛")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PantallaPedidosPreview() {
    DonuteriaTheme {
        PantallaPedidos("Sofis", "Chocolate", true, false, true)
    }
}
