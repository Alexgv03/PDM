package com.example.donutworry

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btnRealizarPedido: Button = findViewById(R.id.btnRealizarPedido)

        val btnVerHistorial: Button = findViewById(R.id.btnVerHistorial)

        btnRealizarPedido.setOnClickListener {
            startActivity(Intent(this, PedidosActivity::class.java))
        }

        btnVerHistorial.setOnClickListener {
            startActivity(Intent(this, HistorialActivity::class.java))
        }

    }
}