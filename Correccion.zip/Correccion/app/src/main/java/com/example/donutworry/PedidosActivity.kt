package com.example.donutworry

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PedidosActivity : AppCompatActivity() {

    private var total = 0.0
    private val precioBase = 35.0
    private val precioExtra = 5.0

    private lateinit var tvTotal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pedidos)

        val rgSabores: RadioGroup = findViewById(R.id.rgSabores)
        val rbChocolate: RadioButton = findViewById(R.id.rbChocolate)
        val rbVainilla: RadioButton = findViewById(R.id.rbVainilla)
        val rbFresa: RadioButton = findViewById(R.id.rbFresa)
        val cbChispas: CheckBox = findViewById(R.id.cbChispas)
        val cbAzucar: CheckBox = findViewById(R.id.cbAzucar)
        val cbRelleno: CheckBox = findViewById(R.id.cbRelleno)
        val etNombre: EditText = findViewById(R.id.etNombre)
        val etDireccion: EditText = findViewById(R.id.etDireccion)
        val btnRealizarPedido: Button = findViewById(R.id.btnRealizarPedido)
        val btnRegresarPedidos: Button = findViewById(R.id.btnRegresarPedidos)
        tvTotal = findViewById(R.id.tvTotal)

        val listener = { actualizarTotal() }
        rgSabores.setOnCheckedChangeListener { _, _ -> listener() }
        cbChispas.setOnCheckedChangeListener { _, _ -> listener() }
        cbAzucar.setOnCheckedChangeListener { _, _ -> listener() }
        cbRelleno.setOnCheckedChangeListener { _, _ -> listener() }

        btnRegresarPedidos.setOnClickListener {
            finish()
        }

        btnRealizarPedido.setOnClickListener {
            val saborSeleccionado = when (rgSabores.checkedRadioButtonId) {
                R.id.rbChocolate -> "Chocolate"
                R.id.rbVainilla -> "Vainilla"
                R.id.rbFresa -> "Fresa"
                else -> "Ninguno"
            }

            val extrasSeleccionados = mutableListOf<String>()
            if (cbChispas.isChecked) extrasSeleccionados.add("Chispas")
            if (cbAzucar.isChecked) extrasSeleccionados.add("Azúcar Glass")
            if (cbRelleno.isChecked) extrasSeleccionados.add("Relleno")

            val nombre = etNombre.text.toString()
            val direccion = etDireccion.text.toString()

            val intent = Intent(this, DetallePedidoActivity::class.java)
            intent.putExtra("sabor", saborSeleccionado)
            intent.putExtra("extras", extrasSeleccionados.joinToString(", "))
            intent.putExtra("nombre", nombre)
            intent.putExtra("direccion", direccion)
            intent.putExtra("total", total)

            startActivity(intent)
        }

        actualizarTotal()
    }

    private fun actualizarTotal() {
        total = precioBase

        if (findViewById<CheckBox>(R.id.cbChispas).isChecked) total += precioExtra
        if (findViewById<CheckBox>(R.id.cbAzucar).isChecked) total += precioExtra
        if (findViewById<CheckBox>(R.id.cbRelleno).isChecked) total += precioExtra

        tvTotal.text = "Total: $${"%.2f".format(total)}"
    }
}